package com.example.beejceej.coinz

import android.os.AsyncTask
import android.util.Log
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

private val TAG = "DownloadFileTask"
class DownloadFileTask(private val caller: DownloadCompleteListener) :
            AsyncTask<String, Void, String>() {

        override fun doInBackground(vararg urls: String): String = try {
            Log.d(TAG, "[loadFileFromNetwork] about to be called")
            loadFileFromNetwork(urls[0])
        } catch (e: IOException){
            "Unable to load content. Check your network connection"
        }
        //loadFileFromNetwork is not being called
        private fun loadFileFromNetwork(urlString: String): String{
            val stream : InputStream = downloadUrl(urlString)
            //Read input from stream, build result as string
            Log.d(TAG, "[loadFileFromNetwork] executing")

            val result = stream.bufferedReader().use(BufferedReader::readText)

            return result
        }

        @Throws(IOException::class)
        private fun downloadUrl(urlString: String) : InputStream {
            Log.d(TAG, "[downloadUrl] executing and urlString is $urlString")
            val url = URL(urlString)
            val conn = url.openConnection() as HttpURLConnection
            conn.readTimeout = 10000 //milliseconds
            conn.connectTimeout = 15000 //milliseconds
            conn.requestMethod = "GET"
            conn.doInput = true
            conn.connect() //starts query
            return conn.inputStream
        }

        override fun onPostExecute(result: String) {
            super.onPostExecute(result)
            Log.d(TAG, "[onPostExecute] executing")
            caller.downloadComplete(result)
        }
    }
