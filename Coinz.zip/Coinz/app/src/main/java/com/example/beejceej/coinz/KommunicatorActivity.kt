package com.example.beejceej.coinz

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import kotlinx.android.synthetic.main.activity_kommunicator.*
import org.jetbrains.anko.toast

class KommunicatorActivity: AppCompatActivity() {
    companion object {
        private const val TAG = "KommunicatorActivity"
        private const val COLLECTION_KEY = "Chat"
        private const val DOCUMENT_KEY = "Message"
        private const val NAME_FIELD = "Name"
        private const val TEXT_FIELD = "Text"
    }

    //init Cloud Firestore
    private var firestore:FirebaseFirestore? = null
    private var firestoreChat: DocumentReference? = null

    override fun onCreate(savedInstanceState: Bundle?){
        Log.d(TAG, "[onCreate] running")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kommunicator)
        setSupportActionBar(findViewById(R.id.toolbar))
        back_to_main.setOnClickListener {
            val intent = Intent(applicationContext, MainActivity::class.java)
            startActivity(intent)
        }
        send_message_button.setOnClickListener{ _-> sendMessage()}
        firestore = FirebaseFirestore.getInstance()

        //val settings = FirebaseFirestoreSettings.Builder()
                //.setTimestampsInSnapshotsEnabled(true)
                //.build()
        //firestore?.firestoreSettings = settings
        firestoreChat = firestore?.collection(COLLECTION_KEY)
                ?.document(DOCUMENT_KEY)
        realtimeUpdateListener()

    }


    private fun  sendMessage(){
        //create message of form {"Name":str1, "Text":str2}
        val newMessage = mapOf(
                NAME_FIELD to name_text.text.toString(),
                TEXT_FIELD to outgoing_message_text.text.toString()
        )

        //send the message and listen for success/failure
        firestoreChat?.set(newMessage)
                ?.addOnSuccessListener { toast("Message send!") } //anko
                ?.addOnFailureListener { _ -> Log.e("TAG", "Failed to send message!") }
    }

    private fun realtimeUpdateListener() {
        firestoreChat?.addSnapshotListener{documentSnapshot, e ->
            when{
                e!=null -> Log.e("TAG", e.message)
                documentSnapshot != null && documentSnapshot.exists() -> {
                    with(documentSnapshot){
                        val incoming = "${data?.get(NAME_FIELD)}:" +
                                "${data?.get(TEXT_FIELD)}"
                        incoming_message_text.text = incoming
                    }
                }
            }

        }
    }
}