package com.example.beejceej.coinz

import android.content.Intent
import android.os.Bundle

import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_kommunicator.*


class Wallet : AppCompatActivity() {

    private val coinCollection:MutableList<Coin> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wallet)

        setSupportActionBar(findViewById(R.id.toolbar))
        back_to_main.setOnClickListener {
            val intent = Intent(applicationContext, MainActivity::class.java)
            startActivity(intent)
        }
    }

    fun addCoin(coin: Coin){
        coinCollection.add(coin)
    }

    fun bankInCoins(): MutableList<Coin>{
        return coinCollection
    }

    fun emptyWallet(){
        coinCollection.removeAll { coin -> coinCollection.remove(coin)}
    }

}
