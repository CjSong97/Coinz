package com.example.beejceej.coinz

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.location.Location
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat

import android.support.v7.app.ActionBar
import android.util.Log
import android.widget.Toast
import com.beust.klaxon.Json
import com.beust.klaxon.JsonArray
import com.beust.klaxon.JsonObject
import com.beust.klaxon.Parser
import com.mapbox.android.core.location.LocationEngine
import com.mapbox.android.core.location.LocationEngineListener
import com.mapbox.android.core.location.LocationEnginePriority
import com.mapbox.android.core.location.LocationEngineProvider
import com.mapbox.android.core.permissions.PermissionsListener
import com.mapbox.android.core.permissions.PermissionsManager
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.mapboxsdk.Mapbox
import com.mapbox.mapboxsdk.annotations.Marker
import com.mapbox.mapboxsdk.annotations.MarkerOptions
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory
import com.mapbox.mapboxsdk.geometry.LatLng
import com.mapbox.mapboxsdk.maps.MapView
import com.mapbox.mapboxsdk.maps.MapboxMap
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback
import com.mapbox.mapboxsdk.plugins.locationlayer.LocationLayerPlugin
import com.mapbox.mapboxsdk.plugins.locationlayer.OnLocationLayerClickListener
import com.mapbox.mapboxsdk.plugins.locationlayer.modes.CameraMode
import com.mapbox.mapboxsdk.plugins.locationlayer.modes.RenderMode
import com.mapbox.mapboxsdk.style.layers.LineLayer
import com.mapbox.mapboxsdk.style.light.Position
import com.mapbox.mapboxsdk.style.sources.GeoJsonSource
import kotlinx.android.synthetic.main.activity_kommunicator.*
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.doAsync
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), OnMapReadyCallback, PermissionsListener,
        LocationEngineListener {

    //values for downloading json
    private var today:String? = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date())
    var json:String = ""


    //values for parsing json
    private var downloadDate:String? = "" //format: YYYY/MM/DD
    private val preferencesFile = "MyPrefsFile" //for storing preferences

    //private lateinit var toolbar:ActionBar

    private var mapView: MapView? = null
    private var map: MapboxMap? = null

    private lateinit var permissionManager: PermissionsManager
    private lateinit var originLocation: Location
    private lateinit var locationEngine: LocationEngine

    //provide location layer to plugin, provides icon representing user location
    private lateinit var locationLayerPlugin: LocationLayerPlugin
    private val TAG = "MainActivity"

    //using DownloadFileTask as an inner class
    @SuppressLint("StaticFieldLeak")
    inner class DownloadFileTask(private val caller: DownloadCompleteListener) :
            AsyncTask<String, Void, String>() {

        override fun doInBackground(vararg urls: String): String = try {
            Log.d(TAG, "[loadFileFromNetwork] about to be called")
            loadFileFromNetwork(urls[0])
        } catch (e: IOException){
            "Unable to load content. Check your network connection"
        }

        private fun loadFileFromNetwork(urlString: String): String{
            val stream : InputStream = downloadUrl(urlString)
            //Read input from stream, build result as string
            Log.d(TAG, "[loadFileFromNetwork] executing")

           val result = stream.bufferedReader().use(BufferedReader::readText)
            applicationContext.openFileOutput("coinzmap", Context.MODE_PRIVATE).use {
                it.write(result.toByteArray())
            }
            return result
        }

        @Throws(IOException::class)
        private fun downloadUrl(urlString: String) : InputStream {
            Log.d(TAG, "[downloadUrl] executing and urlString is $urlString")
            val url = URL(urlString)
            val conn = url.openConnection() as HttpURLConnection
            conn.readTimeout = 10000 //milliseconds
            conn.connectTimeout = 15000 //milliseconds
            conn.requestMethod = "GET"
            conn.doInput = true
            conn.connect() //starts query
            return conn.inputStream
        }

        override fun onPostExecute(result: String) {
            super.onPostExecute(result)
            Log.d(TAG, "[onPostExecute] executing")
            //use klaxon to parse result as geojson

            json = result

            //jsonCollection = parseStringAsJson(result)
            caller.downloadComplete(result)
        }
    }

    private fun addMarkers(){
                //changing result into a geojson and extracting features
                val featureCollection = FeatureCollection.fromJson((json))
                val features = featureCollection.features()
                Log.d("TAG", "[addMarkers] going to be executed ")
                var i = 0

            features?.let {
                for (f in it) {

                    if (f.geometry() is Point) {
                        val geometry = f.geometry() as Point
                        val number = "$i"
                        //val markerColor= f.getNumberProperty("marker-color")
                        Log.d(TAG, "coordinates are $geometry")
                        map?.addMarker(
                                MarkerOptions().position(LatLng(geometry.latitude(),
                                        geometry.longitude())))
                                MarkerOptions().title(number)
                        //need to add marker colors using icon and number

                    }
                    else i++
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbar))

        //configuring navigation buttons for activities
        wallet_button.setOnClickListener {
            val intent = Intent(applicationContext, Wallet::class.java)
            startActivity(intent)
        }

        bank_button.setOnClickListener{
            val intent = Intent(applicationContext, Bank::class.java)
            startActivity(intent)
        }

        message_button.setOnClickListener{
            val intent = Intent(applicationContext, KommunicatorActivity::class.java)
            startActivity(intent)
        }
        //check what date was last downloaded, if same as today
        //just reload last json string
        val settings = getSharedPreferences(preferencesFile, Context.MODE_PRIVATE)
        if(settings.getString("lastDownloadDate", "") == today){
            json = settings.getString("lastJsonFile", "")!!
        } else{
            //async task
            val url = "http://homepages.inf.ed.ac.uk/stg/coinz/$today/coinzmap.geojson"
            DownloadFileTask(DownloadCompleteRunner).execute(url)
            Log.d(TAG, "[onCreate] executing DownloadFileTask")
        }




        Mapbox.getInstance(this , getString(R.string.access_token))
        mapView = findViewById(R.id.mapView)
        mapView?.onCreate(savedInstanceState)
        mapView?.getMapAsync (this)

    }

    override fun onMapReady(mapboxMap: MapboxMap?) {


        if(mapboxMap == null){
            Log.d(TAG, "[onMapReady] mapboxMap is null")
        } else {
            map = mapboxMap
            //set user interface options
            map?.uiSettings?.isCompassEnabled = true
            map?.uiSettings?.isZoomControlsEnabled = true
            addMarkers()
            // make location information available
            enableLocation()

            //called when marker is clicked to check whether user is close enough
            //then stores the coin if they are
            map?.setOnMarkerClickListener{marker ->
                clickedMarker(marker)
                true
            }

        }
    }

    private fun clickedMarker(marker: Marker){
        Log.d(TAG,"marker has been clicked")
        val latLng = marker.position
        val mark:Location = Location("dummy")
        mark.latitude = latLng.latitude
        mark.longitude = latLng.longitude
        if(locationEngine.lastLocation.distanceTo(mark)
                < 25 ){
            val featureCollection = FeatureCollection.fromJson((json))
            val features = featureCollection.features()
            val index = marker.title as Int?
            val mark:Feature = features!![index!!]
            val id:String = mark.getStringProperty("id")
            val value:Double = mark.getNumberProperty("value") as Double
            val currency:String = mark.getStringProperty("currency")
            val coin = Coin(id, value, currency)
            coin.collectCoin()

            //remove the marker after coin collection
            map?.removeMarker(marker)


        }
        else Toast.makeText(this, "Too far away!", Toast.LENGTH_SHORT).show()
    }


    private fun enableLocation() {
        //check whether permission granted for location
        if (PermissionsManager.areLocationPermissionsGranted(this)) {
            Log.d(TAG, "Permissions are granted")
            initializeLocationEngine()
            initializeLocationLayer()
        } else {
            Log.d(TAG, "Permissions NOT granted")
            permissionManager = PermissionsManager(this)
            permissionManager.requestLocationPermissions(this)
        }
    }

    @SuppressWarnings("MissingPermission")
    private fun initializeLocationEngine() {
        locationEngine = LocationEngineProvider(this).obtainBestLocationEngineAvailable()
        locationEngine.apply {
            interval = 5000
            fastestInterval = 1000
            priority = LocationEnginePriority.HIGH_ACCURACY
            activate()
        }

        val lastLocation = locationEngine.lastLocation
        if (lastLocation != null) {
            originLocation = lastLocation
            setCameraPosition(lastLocation)
        } else {
            locationEngine.addLocationEngineListener(this)
        }
    }

    private fun initializeLocationLayer() {
        if(mapView == null){
            Log.d(TAG, "mapView is null")
        } else {
            if (map == null) {Log.d(TAG, "map is null")
        } else {
                locationLayerPlugin = LocationLayerPlugin(mapView!!,
                        map!!, locationEngine)
                locationLayerPlugin.apply {
                setLocationLayerEnabled(true)
                cameraMode = CameraMode.TRACKING
                renderMode = RenderMode.NORMAL
                }
            }
            }

    }

    private fun setCameraPosition(location: Location) {
        val latlng = LatLng(location.latitude, location.longitude)
        map?.animateCamera(CameraUpdateFactory.newLatLng(latlng))
    }

    override fun onExplanationNeeded(permissionsToExplain: MutableList<String>?) {
        Log.d(TAG, "Permissions: $permissionsToExplain")
    }

    override fun onPermissionResult(granted: Boolean) {
        Log.d(TAG, "[onPermissionResult] granted == $granted")
        if (granted) {
            enableLocation()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        permissionManager.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun onLocationChanged(location: Location?) {
        if (location == null){
            Log.d(TAG, "[onLocationChanged] is null")
        } else {
            originLocation = location
            setCameraPosition(originLocation)
            }

    }

    @SuppressWarnings("MissingPermission")
    override fun onConnected() {
        Log.d(TAG, "[onConnected] requesting location updates")
        locationEngine.requestLocationUpdates()
    }

    @SuppressWarnings("MissingPermission")
    override fun onStart() {
        super.onStart()

        //Restore preferences
        val settings = getSharedPreferences(preferencesFile, Context.MODE_PRIVATE)

        //use "" as the default value (might be first time app is run)
        downloadDate = settings.getString("lastDownloadDate", "")

        //Write message to logcat
        Log.d(TAG, "[onStart] Recalled lastDownloadDate = '$downloadDate'")
        mapView?.onStart()
    }

    override fun onResume() {
        super.onResume()
        mapView?.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView?.onPause()
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "[onStop] Storing lastDownloadDate of $today")

        //All objects are from android.context.Context
        val settings = getSharedPreferences(preferencesFile, Context.MODE_PRIVATE)

        //Need Editor object to make preference changes
        val editor = settings.edit()
        editor.putString("lastDownloadDate", today)
        editor.putString("lastJsonFile", json)
        //Apply edits
        editor.apply()

        mapView?.onStop()
        locationEngine.removeLocationUpdates()
        locationLayerPlugin.onStop()

    }

    override fun onDestroy() {
        super.onDestroy()
        mapView?.onDestroy()
        locationEngine.deactivate()
    }

    override fun onSaveInstanceState(outState: Bundle?) {
        super.onSaveInstanceState(outState)
        if (outState != null) {
            mapView?.onSaveInstanceState(outState)
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView?.onLowMemory()
    }
}