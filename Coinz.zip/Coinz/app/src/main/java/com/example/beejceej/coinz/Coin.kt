package com.example.beejceej.coinz

import com.google.firebase.firestore.FirebaseFirestore
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.mapboxsdk.annotations.Marker

class Coin(id:String, value:Double, currency:String){
    private val mainActivity:MainActivity = MainActivity()
    private val wallet:Wallet = Wallet()
    var id = String()
    var value:Double = 0.0
    var currency = String()

    init{
        this.id = id
        this.value = value
        this.currency = currency
    }
    fun  collectCoin(){


        //save these properties into wallet
        wallet.addCoin(this)
    }

}