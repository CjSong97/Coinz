package com.example.beejceej.coinz

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_bank.*
import org.json.JSONObject


class Bank : AppCompatActivity() {
    private val wallet:Wallet = Wallet()
    private val TAG = "Bank"
    private val mainActivity:MainActivity = MainActivity()
    private var dollarRate:Double = 0.0
    private var shilRate:Double = 0.0
    private var quidRate:Double = 0.0
    private var penyRate:Double = 0.0
    private var coins:MutableList<Coin> = mutableListOf()
    private var scoreReference:DocumentReference = FirebaseFirestore.getInstance().
            document("scoreData/score")
    private var score = HashMap<String, Any>()
    private val preferencesFile = "MyPrefsFile"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bank)
        setSupportActionBar(findViewById(R.id.toolbar))

        val settings = getSharedPreferences(preferencesFile, Context.MODE_PRIVATE)
        val lastScore = settings.getString("lastScore", "0")

        val textView = findViewById<TextView>(R.id.current_score)
        textView.text = lastScore
        cash_in.setOnClickListener{
            cashIn()
            Toast.makeText(this, "Cashed In!", Toast.LENGTH_SHORT).show()
        }

        back_main.setOnClickListener {
            val intent = Intent(applicationContext, MainActivity::class.java)
            startActivity(intent)
        }
    }

    private fun getRates(){
        val json = mainActivity.json
        val features = JSONObject(json)
        val rateFeatures = features.getJSONObject("rates")
        dollarRate = rateFeatures.getDouble("DOLR")
        shilRate = rateFeatures.getDouble("SHIL")
        quidRate = rateFeatures.getDouble("QUID")
        penyRate = rateFeatures.getDouble("PENY")
    }

    private fun cashIn(){
        getRates()
        var sum = 0.0
        coins = wallet.bankInCoins()
        for (coin in coins){
            when {
                coin.currency == "DOLR" -> sum += (coin.value * dollarRate)
                coin.currency == "SHIL" -> sum += (coin.value * shilRate)
                coin.currency == "QUID" -> sum += (coin.value * quidRate)
                coin.currency == "PENY" -> sum += (coin.value * penyRate)
            }
        }

        //now add sum to the database
        score["score_key"] = sum
        scoreReference.set(score).addOnSuccessListener {
            Log.d(TAG, "Score has been saved")
        }.addOnFailureListener {
            Log.w(TAG, "Score was not saved!")
        }

        wallet.emptyWallet()

        val settings = getSharedPreferences(preferencesFile, Context.MODE_PRIVATE)

        //Need Editor object to make preference changes
        val editor = settings.edit()
        editor.putString("lastScore", "$sum")
        editor.apply()

    }

}
